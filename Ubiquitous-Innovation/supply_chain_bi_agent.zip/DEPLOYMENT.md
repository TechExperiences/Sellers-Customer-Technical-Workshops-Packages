# Foundry Base Agent — Deployment Guide

This repository contains Infrastructure-as-Code (Bicep + compiled ARM JSON) to deploy a
basic Microsoft Foundry (Azure AI Foundry) agent backed by the **gpt-4.1-mini** model.

## Safe action-handler prototype

The `prototype/` directory contains a local, dependency-free Node.js demonstration of a
purchase-requisition-style tool handler. It uses deterministic local grounding data and
an in-memory mock adapter only. It does not connect to Foundry tools, procurement
systems, or any other enterprise service, and it performs no live writes.

Run its tests from the prototype directory with Node.js 18 or later:

```powershell
Set-Location prototype
npm run demo
npm test
```

The contract is versioned (`1.0`), requires both `dry_run` and `correlation_id`, and
the runnable demo defaults to dry-run. A simulated non-dry-run flow requires
a separate, correlation-bound user confirmation and simulated human approval. This is demo control flow, not
a production authorization or approval mechanism. The handler denies by default,
checks a deterministic fixture, rejects conflicting idempotency-key reuse, does not
retry, and emits structured audit states without raw request or approval payloads.
All successful outcomes are labeled as simulated.

The corresponding safe agent behavior is documented in
[`prototype/AGENT_INSTRUCTIONS.md`](prototype/AGENT_INSTRUCTIONS.md).

The prototype is not wired into the Foundry agent deployment below. No platform
integration, production adapter, enterprise credentials, or live write capability is
available in this repository.

## What gets deployed

| Resource | Type | Purpose |
| --- | --- | --- |
| `ubiq-foundry-acct` | `Microsoft.CognitiveServices/accounts` (kind `AIServices`) | The Foundry account |
| `gpt-4.1-mini` | `Microsoft.CognitiveServices/accounts/deployments` | Model deployment used by the agent |
| `ubiq-foundry-proj` | `Microsoft.CognitiveServices/accounts/projects` | Foundry project that hosts the agent |
| `ubiq-foundry-agent-deployer-id` | `Microsoft.ManagedIdentity/userAssignedIdentities` | Identity used only to call the Agents REST API during deployment |
| Role assignment | `Microsoft.Authorization/roleAssignments` | Grants the deployer identity the **Foundry User** role on the project |
| `ubiq-foundry-create-agent` | `Microsoft.Resources/deploymentScripts` | Azure CLI script that creates (or reuses) the base agent via the Foundry Agents REST API |

The base agent is created with:
- **Model:** `gpt-4.1-mini`
- **Instructions:** "You are a helpful assistant that answers questions concisely and accurately."

## Prerequisites

- Azure CLI 2.60+ (`az --version`)
- Bicep CLI (bundled with Azure CLI, or `az bicep install`)
- Permissions on the subscription/resource group to create Cognitive Services accounts,
  managed identities, role assignments, and deployment scripts
- The existing resource group **`rg-ubiquitous`**
- Quota for the `gpt-4.1-mini` model in the target region (default: `eastus2`)

## Repository layout

```
arm/
├── main.bicep              # Main Bicep template (source of truth)
├── main.json                # Compiled ARM JSON template (equivalent to main.bicep)
├── main.parameters.json     # Default parameter values
└── scripts/
    └── create-agent.sh      # Script run by the deploymentScript resource to create the agent
```

## Deploy

1. Sign in and select the subscription that contains `rg-ubiquitous`:

   ```powershell
   az login
   az account set --subscription "<subscription-name-or-id>"
   ```

2. (Optional) Review/update `arm/main.parameters.json` — in particular `location`,
   `foundryAccountName`, `foundryProjectName`, `agentName`, and `agentInstructions`.

3. Deploy using Bicep (recommended):

   ```powershell
   az deployment group create `
     --resource-group rg-ubiquitous `
     --name foundry-agent-deploy `
     --template-file arm/main.bicep `
     --parameters arm/main.parameters.json
   ```

   Or deploy using the compiled ARM JSON template:

   ```powershell
   az deployment group create `
     --resource-group rg-ubiquitous `
     --name foundry-agent-deploy `
     --template-file arm/main.json `
     --parameters arm/main.parameters.json
   ```

4. Confirm the agent was created:

   ```powershell
   az deployment group show `
     --resource-group rg-ubiquitous `
     --name foundry-agent-deploy `
     --query properties.outputs
   ```

   The output includes `agentId`, `projectEndpoint`, `foundryAccountName`,
   `foundryProjectName`, and `modelDeploymentName`.

## Verify the agent in the portal

1. Go to [Microsoft Foundry portal](https://ai.azure.com).
2. Open the `ubiq-foundry-proj` project under the `ubiq-foundry-acct` account.
3. Navigate to **Agents** — the `basic-agent` agent should be listed, using the
   `gpt-4.1-mini` model deployment.

## Notes

- The deployment script is idempotent: if an agent with the same name already exists in
  the project, the script reuses it instead of creating a duplicate.
- The `gpt-4.1-mini` model version (`2025-04-14`) and SKU (`GlobalStandard`) were verified
  as available in `eastus2` for this subscription. Run
  `az cognitiveservices model list --location <region>` to check availability in a
  different region before changing `location`.
- To update the agent's instructions or model later, redeploy with updated parameter
  values, or use the Foundry SDK/REST API directly.

## Clean up

To remove all resources created by this template:

```powershell
az group delete --name rg-ubiquitous --yes --no-wait
```

> Only run this if `rg-ubiquitous` is dedicated to this deployment — it will delete
> **everything** in the resource group, not just the resources created here.
