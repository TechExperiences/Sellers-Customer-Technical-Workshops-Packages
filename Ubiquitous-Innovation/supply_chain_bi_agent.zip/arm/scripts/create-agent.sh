#!/bin/bash
set -euo pipefail

# Required env vars (provided by the deploymentScript resource):
#   PROJECT_ENDPOINT, MODEL_DEPLOYMENT_NAME, AGENT_NAME, AGENT_INSTRUCTIONS
API_VERSION="2025-05-01"
RESOURCE="https://ai.azure.com"

# Check whether an agent with this name already exists so re-runs are idempotent.
echo "Checking for existing agent named '${AGENT_NAME}'..."
EXISTING_ID=$(az rest --method get \
  --url "${PROJECT_ENDPOINT}/assistants?api-version=${API_VERSION}" \
  --resource "${RESOURCE}" \
  --query "data[?name=='${AGENT_NAME}'] | [0].id" -o tsv || true)

if [ -n "${EXISTING_ID}" ] && [ "${EXISTING_ID}" != "None" ]; then
  echo "Agent already exists with id ${EXISTING_ID}. Skipping creation."
  AGENT_ID="${EXISTING_ID}"
else
  echo "Creating agent '${AGENT_NAME}' with model deployment '${MODEL_DEPLOYMENT_NAME}'..."
  BODY=$(printf '{"model": "%s", "name": "%s", "instructions": "%s"}' \
    "${MODEL_DEPLOYMENT_NAME}" "${AGENT_NAME}" "${AGENT_INSTRUCTIONS}")

  AGENT_ID=$(az rest --method post \
    --url "${PROJECT_ENDPOINT}/assistants?api-version=${API_VERSION}" \
    --resource "${RESOURCE}" \
    --body "${BODY}" \
    --query "id" -o tsv)

  if [ -z "${AGENT_ID}" ] || [ "${AGENT_ID}" = "None" ]; then
    echo "Failed to create agent."
    exit 1
  fi
  echo "Created agent with id ${AGENT_ID}."
fi

mkdir -p "$(dirname "$AZ_SCRIPTS_OUTPUT_PATH")"
echo "{\"agentId\": \"${AGENT_ID}\"}" > "$AZ_SCRIPTS_OUTPUT_PATH"
