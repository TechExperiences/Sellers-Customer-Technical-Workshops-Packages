// Deploys a Microsoft Foundry (Azure AI Foundry) account + project, a GPT-4.1-mini
// model deployment, and a basic persistent agent using the existing resource group.
targetScope = 'resourceGroup'

@description('Azure region for all resources. Must be a region that supports Microsoft Foundry and the gpt-4.1-mini model.')
param location string = resourceGroup().location

@minLength(2)
@maxLength(32)
@description('Base name used to derive resource names (account, project, identity).')
param baseName string = 'ubiq-foundry'

@description('Name of the Foundry (Cognitive Services AIServices) account.')
param foundryAccountName string = '${baseName}-acct'

@description('Name of the Foundry project.')
param foundryProjectName string = '${baseName}-proj'

@description('Display name shown in the Foundry portal for the project.')
param foundryProjectDisplayName string = 'Ubiquitous Foundry Project'

@description('Name of the model deployment that backs the agent.')
param modelDeploymentName string = 'gpt-4.1-mini'

@description('Underlying model name to deploy.')
param modelName string = 'gpt-4.1-mini'

@description('Model version to deploy. Verify availability with: az cognitiveservices account list-models.')
param modelVersion string = '2025-04-14'

@description('SKU name for the model deployment.')
@allowed([
  'GlobalStandard'
  'Standard'
  'DataZoneStandard'
])
param modelSkuName string = 'GlobalStandard'

@description('Tokens-per-minute capacity (in thousands) for the model deployment.')
param modelCapacity int = 10

@description('Name of the base agent to create.')
param agentName string = 'basic-agent'

@description('One-line system instruction for the agent.')
param agentInstructions string = 'You are a helpful assistant that answers questions concisely and accurately.'

@description('Tags applied to all resources.')
param tags object = {
  project: 'ubiquitous-innovation'
  environment: 'dev'
}

var customSubDomainName = toLower(replace(foundryAccountName, '_', '-'))
var identityName = '${baseName}-agent-deployer-id'
// Built-in "Foundry User" role (formerly "Azure AI User"). ID is stable across the rename.
var foundryUserRoleId = '53ca6127-db72-4b80-b1b0-d745d6d5456d'

resource foundryAccount 'Microsoft.CognitiveServices/accounts@2025-06-01' = {
  name: foundryAccountName
  location: location
  tags: tags
  sku: {
    name: 'S0'
  }
  kind: 'AIServices'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    allowProjectManagement: true
    customSubDomainName: customSubDomainName
    disableLocalAuth: false
    publicNetworkAccess: 'Enabled'
  }
}

resource modelDeployment 'Microsoft.CognitiveServices/accounts/deployments@2025-06-01' = {
  parent: foundryAccount
  name: modelDeploymentName
  sku: {
    name: modelSkuName
    capacity: modelCapacity
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: modelName
      version: modelVersion
    }
  }
}

resource foundryProject 'Microsoft.CognitiveServices/accounts/projects@2025-06-01' = {
  parent: foundryAccount
  name: foundryProjectName
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    displayName: foundryProjectDisplayName
    description: 'Base project hosting the ${agentName} agent.'
  }
}

// User-assigned identity used only to call the Agents REST API during deployment.
resource deployerIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: identityName
  location: location
  tags: tags
}

// Grants the deployer identity permission to create agents on the project.
resource agentCreatorRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(foundryProject.id, deployerIdentity.id, foundryUserRoleId)
  scope: foundryProject
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', foundryUserRoleId)
    principalId: deployerIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// Creates (or reuses) the base agent via the Foundry Agents REST API.
resource createAgentScript 'Microsoft.Resources/deploymentScripts@2023-08-01' = {
  name: '${baseName}-create-agent'
  location: location
  tags: tags
  kind: 'AzureCLI'
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${deployerIdentity.id}': {}
    }
  }
  properties: {
    azCliVersion: '2.61.0'
    retentionInterval: 'P1D'
    timeout: 'PT10M'
    cleanupPreference: 'OnSuccess'
    environmentVariables: [
      {
        name: 'PROJECT_ENDPOINT'
        value: 'https://${foundryAccount.properties.customSubDomainName}.services.ai.azure.com/api/projects/${foundryProjectName}'
      }
      {
        name: 'MODEL_DEPLOYMENT_NAME'
        value: modelDeploymentName
      }
      {
        name: 'AGENT_NAME'
        value: agentName
      }
      {
        name: 'AGENT_INSTRUCTIONS'
        value: agentInstructions
      }
    ]
    scriptContent: loadTextContent('scripts/create-agent.sh')
  }
  dependsOn: [
    agentCreatorRoleAssignment
    modelDeployment
  ]
}

output foundryAccountName string = foundryAccount.name
output foundryProjectName string = foundryProject.name
output projectEndpoint string = 'https://${foundryAccount.properties.customSubDomainName}.services.ai.azure.com/api/projects/${foundryProjectName}'
output modelDeploymentName string = modelDeployment.name
output agentId string = createAgentScript.properties.outputs.agentId
