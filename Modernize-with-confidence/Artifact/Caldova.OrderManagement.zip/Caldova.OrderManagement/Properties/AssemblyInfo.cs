using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Caldova.OrderManagement")]
[assembly: AssemblyDescription("Caldova legacy order management web application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Caldova")]
[assembly: AssemblyProduct("Caldova.OrderManagement")]
[assembly: AssemblyCopyright("Copyright (c) Caldova")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("6b0f6b6e-8f3a-4e2b-9a6a-7a4a2b8f3c1d")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
