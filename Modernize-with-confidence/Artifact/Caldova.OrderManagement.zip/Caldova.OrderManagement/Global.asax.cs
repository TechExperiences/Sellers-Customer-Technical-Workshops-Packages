using System;
using System.Web.Mvc;
using System.Web.Routing;
using Caldova.OrderManagement.App_Start;
using Caldova.OrderManagement.Data;

namespace Caldova.OrderManagement
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            FileLogger.Info("Application started.");
        }

        // Basic exception handling: log every unhandled exception (including outside MVC
        // action execution, e.g. routing errors) and let customErrors show the friendly page.
        protected void Application_Error()
        {
            var exception = Server.GetLastError();
            if (exception != null)
            {
                FileLogger.Error("Unhandled application exception at " + Request.Path, exception);
            }
        }

        protected void Application_End()
        {
            FileLogger.Info("Application stopped.");
        }
    }
}
