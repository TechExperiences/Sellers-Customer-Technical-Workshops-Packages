using System.Web.Mvc;
using Caldova.OrderManagement.Data;

namespace Caldova.OrderManagement.App_Start
{
    // Extends the standard MVC error handler so every unhandled action exception is file-logged.
    public class LoggingHandleErrorAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            if (filterContext.ExceptionHandled == false)
            {
                FileLogger.Error("Unhandled action exception in " +
                    filterContext.RouteData.Values["controller"] + "/" +
                    filterContext.RouteData.Values["action"], filterContext.Exception);
            }

            base.OnException(filterContext);
        }
    }
}
