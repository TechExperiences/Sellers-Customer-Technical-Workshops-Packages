using System.Web.Mvc;

namespace Caldova.OrderManagement.App_Start
{
    public static class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            // Logs unhandled exceptions and shows the friendly Error view (basic exception handling).
            filters.Add(new LoggingHandleErrorAttribute());
        }
    }
}
