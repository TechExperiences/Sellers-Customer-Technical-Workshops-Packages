using System.Collections.Generic;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Services
{
    public interface IOrderService
    {
        OrderCreateViewModel PrepareCreateForm();
        ServiceResult<int> CreateOrder(OrderCreateViewModel model, string createdBy);
        ServiceResult<OrderDetailsModel> GetById(int orderId);
        ServiceResult<bool> UpdateStatus(int orderId, string newStatus);
    }
}
