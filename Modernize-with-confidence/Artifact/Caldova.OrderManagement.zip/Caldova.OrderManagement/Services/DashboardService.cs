using Caldova.OrderManagement.Models;
using Caldova.OrderManagement.Repositories;

namespace Caldova.OrderManagement.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly IDashboardRepository _repository;

        public DashboardService() : this(new DashboardRepository())
        {
        }

        public DashboardService(IDashboardRepository repository)
        {
            _repository = repository;
        }

        public DashboardViewModel GetDashboard()
        {
            return new DashboardViewModel
            {
                TotalProducts = _repository.GetTotalProducts(),
                AvailableProducts = _repository.GetAvailableProductsCount(),
                OpenOrders = _repository.GetOpenOrdersCount(),
                PendingShipments = _repository.GetPendingShipmentsCount()
            };
        }
    }
}
