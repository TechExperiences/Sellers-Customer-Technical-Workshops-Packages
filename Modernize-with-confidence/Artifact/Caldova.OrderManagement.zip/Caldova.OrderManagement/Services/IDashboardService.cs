using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Services
{
    public interface IDashboardService
    {
        DashboardViewModel GetDashboard();
    }
}
