using System.Collections.Generic;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Services
{
    public interface IProductService
    {
        List<ProductAvailabilityModel> Search(ProductSearchCriteria criteria);
    }
}
