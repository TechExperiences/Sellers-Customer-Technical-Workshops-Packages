using System.Collections.Generic;
using Caldova.OrderManagement.Data;
using Caldova.OrderManagement.Models;
using Caldova.OrderManagement.Repositories;

namespace Caldova.OrderManagement.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _repository;

        public ProductService() : this(new ProductRepository())
        {
        }

        public ProductService(IProductRepository repository)
        {
            _repository = repository;
        }

        public List<ProductAvailabilityModel> Search(ProductSearchCriteria criteria)
        {
            if (criteria.IsEmpty)
            {
                return new List<ProductAvailabilityModel>();
            }

            FileLogger.Info("Product search executed: " +
                "ProductId=" + criteria.ProductId + ", Sku=" + criteria.Sku +
                ", ProductName=" + criteria.ProductName + ", Category=" + criteria.Category +
                ", DescriptionKeyword=" + criteria.DescriptionKeyword);

            return _repository.Search(criteria);
        }
    }
}
