using System.Collections.Generic;
using Caldova.OrderManagement.Models;
using Caldova.OrderManagement.Repositories;

namespace Caldova.OrderManagement.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _repository;

        public CustomerService() : this(new CustomerRepository())
        {
        }

        public CustomerService(ICustomerRepository repository)
        {
            _repository = repository;
        }

        public List<CustomerModel> Search(CustomerSearchCriteria criteria)
        {
            if (criteria.IsEmpty)
            {
                return new List<CustomerModel>();
            }

            return _repository.Search(criteria);
        }
    }
}
