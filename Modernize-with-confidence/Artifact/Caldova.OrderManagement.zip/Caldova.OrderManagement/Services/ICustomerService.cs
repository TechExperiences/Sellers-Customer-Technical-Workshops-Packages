using System.Collections.Generic;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Services
{
    public interface ICustomerService
    {
        List<CustomerModel> Search(CustomerSearchCriteria criteria);
    }
}
