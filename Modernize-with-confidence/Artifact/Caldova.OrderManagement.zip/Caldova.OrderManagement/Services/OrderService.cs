using System;
using System.Linq;
using System.Web.Mvc;
using Caldova.OrderManagement.Data;
using Caldova.OrderManagement.Models;
using Caldova.OrderManagement.Repositories;

namespace Caldova.OrderManagement.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repository;

        public OrderService() : this(new OrderRepository())
        {
        }

        public OrderService(IOrderRepository repository)
        {
            _repository = repository;
        }

        public OrderCreateViewModel PrepareCreateForm()
        {
            var model = new OrderCreateViewModel();
            model.CustomerOptions = _repository.GetCustomersForDropdown()
                .Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.DisplayText })
                .ToList();
            model.ProductOptions = _repository.GetProductsForDropdown()
                .Select(p => new SelectListItem { Value = p.Id.ToString(), Text = p.DisplayText })
                .ToList();
            return model;
        }

        public ServiceResult<int> CreateOrder(OrderCreateViewModel model, string createdBy)
        {
            if (model.CustomerId <= 0)
            {
                return ServiceResult<int>.Fail("Please select a customer.");
            }

            var validLines = model.Lines.Where(l => l.ProductId > 0 && l.Quantity > 0).ToList();
            if (!validLines.Any())
            {
                return ServiceResult<int>.Fail("Add at least one product with a quantity greater than zero.");
            }

            try
            {
                string orderNumber;
                var orderId = _repository.CreateOrder(model.CustomerId, validLines, createdBy, out orderNumber);
                FileLogger.Info(string.Format("Order {0} ({1}) created for customer {2} by {3}.",
                    orderId, orderNumber, model.CustomerId, createdBy));
                return ServiceResult<int>.Ok(orderId);
            }
            catch (Exception ex)
            {
                FileLogger.Error("Failed to create order for customer " + model.CustomerId, ex);
                return ServiceResult<int>.Fail("The order could not be saved: " + ex.Message);
            }
        }

        public ServiceResult<OrderDetailsModel> GetById(int orderId)
        {
            try
            {
                var order = _repository.GetById(orderId);
                return order == null
                    ? ServiceResult<OrderDetailsModel>.Fail("No order was found with ID " + orderId + ".")
                    : ServiceResult<OrderDetailsModel>.Ok(order);
            }
            catch (Exception ex)
            {
                FileLogger.Error("Failed to look up order " + orderId, ex);
                return ServiceResult<OrderDetailsModel>.Fail("The order could not be retrieved.");
            }
        }

        public ServiceResult<bool> UpdateStatus(int orderId, string newStatus)
        {
            if (!OrderStatuses.IsValid(newStatus))
            {
                return ServiceResult<bool>.Fail("'" + newStatus + "' is not a supported order status.");
            }

            try
            {
                var updated = _repository.UpdateStatus(orderId, newStatus);
                if (!updated)
                {
                    return ServiceResult<bool>.Fail("No order was found with ID " + orderId + ".");
                }

                FileLogger.Info(string.Format("Order {0} status changed to {1}.", orderId, newStatus));
                return ServiceResult<bool>.Ok(true);
            }
            catch (Exception ex)
            {
                FileLogger.Error("Failed to update status for order " + orderId, ex);
                return ServiceResult<bool>.Fail("The order status could not be updated.");
            }
        }
    }
}
