using System.Configuration;
using System.Data.SqlClient;

namespace Caldova.OrderManagement.Data
{
    // Central place for obtaining ADO.NET connections; connection string lives in Web.config.
    public static class DbHelper
    {
        private static string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["CaldovaOrderManagementConnection"].ConnectionString; }
        }

        public static SqlConnection GetOpenConnection()
        {
            var connection = new SqlConnection(ConnectionString);
            connection.Open();
            return connection;
        }
    }
}
