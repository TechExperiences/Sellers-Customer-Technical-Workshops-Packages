using System;
using System.IO;
using System.Web;

namespace Caldova.OrderManagement.Data
{
    // Basic file-based logging (one file per day under App_Data\Logs). Never throws -
    // logging failures must not break the request.
    public static class FileLogger
    {
        private static readonly object SyncRoot = new object();

        private static string LogDirectory
        {
            get { return HttpContext.Current != null ? HttpContext.Current.Server.MapPath("~/App_Data/Logs") : AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Logs"; }
        }

        public static void Info(string message)
        {
            Write("INFO", message);
        }

        public static void Error(string message, Exception ex)
        {
            Write("ERROR", message + " -- " + ex);
        }

        private static void Write(string level, string message)
        {
            try
            {
                lock (SyncRoot)
                {
                    var dir = LogDirectory;
                    if (!Directory.Exists(dir))
                    {
                        Directory.CreateDirectory(dir);
                    }

                    var filePath = Path.Combine(dir, "app-" + DateTime.UtcNow.ToString("yyyyMMdd") + ".log");
                    var line = string.Format("{0:yyyy-MM-dd HH:mm:ss} [{1}] {2}{3}",
                        DateTime.UtcNow, level, message, Environment.NewLine);
                    File.AppendAllText(filePath, line);
                }
            }
            catch
            {
                // Swallow logging failures - logging must never take the app down.
            }
        }
    }
}
