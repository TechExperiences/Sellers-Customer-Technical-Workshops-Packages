using System.Web.Mvc;
using Caldova.OrderManagement.Models;
using Caldova.OrderManagement.Services;

namespace Caldova.OrderManagement.Controllers
{
    public class OrderController : Controller
    {
        private readonly IOrderService _orderService;

        public OrderController() : this(new OrderService())
        {
        }

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        // Order Management: select customer, add products, enter quantity (Scenario 4).
        [HttpGet]
        public ActionResult Create()
        {
            return View(_orderService.PrepareCreateForm());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(OrderCreateViewModel model)
        {
            var result = _orderService.CreateOrder(model, User.Identity.Name);
            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.Message);
                var refreshed = _orderService.PrepareCreateForm();
                refreshed.CustomerId = model.CustomerId;
                refreshed.Lines = model.Lines;
                return View(refreshed);
            }

            TempData["SuccessMessage"] = "Order created successfully.";
            return RedirectToAction("Details", new { id = result.Data });
        }

        // Order Lookup: search by Order ID (Scenario 2).
        [HttpGet]
        public ActionResult Index(int? orderId)
        {
            var model = new OrderLookupViewModel { OrderId = orderId };

            if (orderId.HasValue)
            {
                model.HasSearched = true;
                var result = _orderService.GetById(orderId.Value);
                if (result.Success)
                {
                    model.Order = result.Data;
                }
                else
                {
                    model.ErrorMessage = result.Message;
                }
            }

            return View(model);
        }

        // Open order details, including order lines (Scenario 3).
        [HttpGet]
        public ActionResult Details(int id)
        {
            var result = _orderService.GetById(id);
            if (!result.Success)
            {
                TempData["ErrorMessage"] = result.Message;
                return RedirectToAction("Index");
            }

            ViewBag.AvailableStatuses = OrderStatuses.All;
            return View(result.Data);
        }

        // Order Status update (Scenario 5).
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateStatus(int orderId, string newStatus)
        {
            var result = _orderService.UpdateStatus(orderId, newStatus);
            TempData[result.Success ? "SuccessMessage" : "ErrorMessage"] =
                result.Success ? "Order status updated to " + newStatus + "." : result.Message;

            return RedirectToAction("Details", new { id = orderId });
        }
    }
}
