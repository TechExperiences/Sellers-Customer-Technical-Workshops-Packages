using System.Web.Mvc;

namespace Caldova.OrderManagement.Controllers
{
    public class ErrorController : Controller
    {
        // Friendly error page target for customErrors / httpErrors (basic exception handling).
        public ActionResult Index()
        {
            Response.StatusCode = 500;
            return View();
        }
    }
}
