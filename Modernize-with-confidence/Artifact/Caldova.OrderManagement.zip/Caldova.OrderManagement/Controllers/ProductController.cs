using System.Web.Mvc;
using Caldova.OrderManagement.Models;
using Caldova.OrderManagement.Services;

namespace Caldova.OrderManagement.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;

        public ProductController() : this(new ProductService())
        {
        }

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        // Product Availability search (Scenario 1: search + check inventory availability;
        // Scenario 6: LIKE search across product descriptions via the Description field).
        [HttpGet]
        public ActionResult Index(ProductSearchCriteria criteria)
        {
            var model = new ProductSearchViewModel { Criteria = criteria ?? new ProductSearchCriteria() };

            if (!model.Criteria.IsEmpty)
            {
                model.HasSearched = true;
                model.Results = _productService.Search(model.Criteria);
            }

            return View(model);
        }
    }
}
