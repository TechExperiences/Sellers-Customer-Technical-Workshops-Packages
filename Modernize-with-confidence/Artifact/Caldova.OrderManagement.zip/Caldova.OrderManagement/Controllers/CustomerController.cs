using System.Web.Mvc;
using Caldova.OrderManagement.Models;
using Caldova.OrderManagement.Services;

namespace Caldova.OrderManagement.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerService _customerService;

        public CustomerController() : this(new CustomerService())
        {
        }

        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        // Customer Lookup: search by Customer ID or Customer Name.
        [HttpGet]
        public ActionResult Index(CustomerSearchCriteria criteria)
        {
            var model = new CustomerSearchViewModel { Criteria = criteria ?? new CustomerSearchCriteria() };

            if (!model.Criteria.IsEmpty)
            {
                model.HasSearched = true;
                model.Results = _customerService.Search(model.Criteria);
            }

            return View(model);
        }
    }
}
