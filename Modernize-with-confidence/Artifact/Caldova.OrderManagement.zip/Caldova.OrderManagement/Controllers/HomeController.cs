using System.Web.Mvc;
using Caldova.OrderManagement.Services;

namespace Caldova.OrderManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly IDashboardService _dashboardService;

        public HomeController() : this(new DashboardService())
        {
        }

        public HomeController(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        // Dashboard: Total Products, Available Products, Open Orders, Pending Shipments.
        public ActionResult Index()
        {
            var model = _dashboardService.GetDashboard();
            return View(model);
        }
    }
}
