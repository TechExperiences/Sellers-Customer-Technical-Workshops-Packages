// Lets the user add extra product/quantity rows on the New Order form without a page reload.
// Kept dependency-free (no jQuery) to match the minimal legacy footprint of this app.
(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {
        var addButton = document.getElementById("add-line-button");
        var table = document.getElementById("order-lines-table");
        if (!addButton || !table) {
            return;
        }

        var tbody = table.getElementsByTagName("tbody")[0];
        var nextIndex = tbody.getElementsByTagName("tr").length;

        addButton.addEventListener("click", function () {
            var templateRow = tbody.getElementsByTagName("tr")[0];
            var newRow = templateRow.cloneNode(true);

            var selects = newRow.getElementsByTagName("select");
            for (var i = 0; i < selects.length; i++) {
                selects[i].name = "Lines[" + nextIndex + "].ProductId";
                selects[i].selectedIndex = 0;
            }

            var inputs = newRow.getElementsByTagName("input");
            for (var j = 0; j < inputs.length; j++) {
                inputs[j].name = "Lines[" + nextIndex + "].Quantity";
                inputs[j].value = "0";
            }

            tbody.appendChild(newRow);
            nextIndex++;
        });
    });
})();
