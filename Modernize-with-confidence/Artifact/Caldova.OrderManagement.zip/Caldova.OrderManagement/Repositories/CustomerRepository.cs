using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Caldova.OrderManagement.Data;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        public List<CustomerModel> Search(CustomerSearchCriteria criteria)
        {
            var sql = new StringBuilder(@"
                SELECT
                    c.CustomerID, c.CompanyName, c.Email, c.Phone,
                    a.AddressLine1, a.City, a.State, a.PostalCode
                FROM dbo.Customers c
                OUTER APPLY (
                    SELECT TOP (1) AddressLine1, City, State, PostalCode
                    FROM dbo.CustomerAddresses
                    WHERE CustomerID = c.CustomerID
                    ORDER BY IsPrimary DESC, AddressID
                ) a
                WHERE c.IsActive = 1");

            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand())
            {
                command.Connection = connection;

                if (criteria.CustomerId.HasValue)
                {
                    sql.Append(" AND c.CustomerID = @CustomerId");
                    command.Parameters.Add("@CustomerId", SqlDbType.Int).Value = criteria.CustomerId.Value;
                }
                if (!string.IsNullOrWhiteSpace(criteria.CustomerName))
                {
                    sql.Append(" AND c.CompanyName LIKE @CustomerName");
                    command.Parameters.Add("@CustomerName", SqlDbType.VarChar, 150).Value = "%" + criteria.CustomerName.Trim() + "%";
                }

                sql.Append(" ORDER BY c.CompanyName;");
                command.CommandText = sql.ToString();

                var results = new List<CustomerModel>();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var addressParts = new List<string>();
                        AddIfPresent(reader, "AddressLine1", addressParts);
                        AddIfPresent(reader, "City", addressParts);
                        AddIfPresent(reader, "State", addressParts);
                        AddIfPresent(reader, "PostalCode", addressParts);

                        results.Add(new CustomerModel
                        {
                            CustomerId = reader.GetInt32(reader.GetOrdinal("CustomerID")),
                            CustomerName = reader.GetString(reader.GetOrdinal("CompanyName")),
                            Email = reader.IsDBNull(reader.GetOrdinal("Email")) ? string.Empty : reader.GetString(reader.GetOrdinal("Email")),
                            Phone = reader.IsDBNull(reader.GetOrdinal("Phone")) ? string.Empty : reader.GetString(reader.GetOrdinal("Phone")),
                            Address = string.Join(", ", addressParts)
                        });
                    }
                }
                return results;
            }
        }

        private static void AddIfPresent(SqlDataReader reader, string column, List<string> target)
        {
            var ordinal = reader.GetOrdinal(column);
            if (!reader.IsDBNull(ordinal))
            {
                target.Add(reader.GetString(ordinal));
            }
        }
    }
}
