using System.Collections.Generic;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Repositories
{
    public interface IProductRepository
    {
        List<ProductAvailabilityModel> Search(ProductSearchCriteria criteria);
    }
}
