using System.Data.SqlClient;
using Caldova.OrderManagement.Data;

namespace Caldova.OrderManagement.Repositories
{
    // Straight ADO.NET (synchronous) - no ORM, matches the legacy data-access pattern.
    public class DashboardRepository : IDashboardRepository
    {
        public int GetTotalProducts()
        {
            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand("SELECT COUNT(*) FROM dbo.ProductCatalog WHERE IsActive = 1;", connection))
            {
                return (int)command.ExecuteScalar();
            }
        }

        public int GetAvailableProductsCount()
        {
            const string sql = @"SELECT COUNT(DISTINCT i.ProductID)
                                  FROM dbo.Inventory i
                                  JOIN dbo.ProductCatalog p ON p.ProductID = i.ProductID
                                  WHERE i.QuantityAvailable > 0 AND p.IsActive = 1;";
            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand(sql, connection))
            {
                return (int)command.ExecuteScalar();
            }
        }

        public int GetOpenOrdersCount()
        {
            const string sql = "SELECT COUNT(*) FROM dbo.Orders WHERE OrderStatus NOT IN ('Delivered', 'Cancelled');";
            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand(sql, connection))
            {
                return (int)command.ExecuteScalar();
            }
        }

        public int GetPendingShipmentsCount()
        {
            const string sql = "SELECT COUNT(*) FROM dbo.Shipments WHERE ShipmentStatus IN ('Preparing', 'Shipped', 'InTransit');";
            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand(sql, connection))
            {
                return (int)command.ExecuteScalar();
            }
        }
    }
}
