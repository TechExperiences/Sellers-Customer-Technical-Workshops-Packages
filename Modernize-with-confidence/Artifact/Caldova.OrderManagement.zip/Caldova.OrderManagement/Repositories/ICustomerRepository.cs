using System.Collections.Generic;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Repositories
{
    public interface ICustomerRepository
    {
        List<CustomerModel> Search(CustomerSearchCriteria criteria);
    }
}
