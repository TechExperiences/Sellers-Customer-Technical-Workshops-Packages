using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Caldova.OrderManagement.Data;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private const decimal TaxRate = 0.07m;
        private const decimal FlatShippingAmount = 15.00m;

        public List<LookupItem> GetCustomersForDropdown()
        {
            const string sql = "SELECT CustomerID, CompanyName FROM dbo.Customers WHERE IsActive = 1 ORDER BY CompanyName;";
            var items = new List<LookupItem>();
            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand(sql, connection))
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    items.Add(new LookupItem { Id = reader.GetInt32(0), DisplayText = reader.GetString(1) });
                }
            }
            return items;
        }

        public List<LookupItem> GetProductsForDropdown()
        {
            const string sql = "SELECT ProductID, SKU + ' - ' + ProductName FROM dbo.ProductCatalog WHERE IsActive = 1 ORDER BY ProductName;";
            var items = new List<LookupItem>();
            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand(sql, connection))
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    items.Add(new LookupItem { Id = reader.GetInt32(0), DisplayText = reader.GetString(1) });
                }
            }
            return items;
        }

        public int CreateOrder(int customerId, List<OrderLineInputModel> lines, string createdBy, out string orderNumber)
        {
            using (var connection = DbHelper.GetOpenConnection())
            using (var transaction = connection.BeginTransaction())
            {
                try
                {
                    var shippingAddressId = GetAddressId(connection, transaction, customerId, "Shipping");
                    var billingAddressId = GetAddressId(connection, transaction, customerId, "Billing");
                    // Legacy single-warehouse fulfillment default; no warehouse picker in the UI per spec.
                    var warehouseId = GetDefaultWarehouseId(connection, transaction);

                    orderNumber = "SO-" + DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");

                    int orderId;
                    using (var insertOrder = new SqlCommand(@"
                        INSERT INTO dbo.Orders
                            (OrderNumber, CustomerID, ShippingAddressID, BillingAddressID, WarehouseID, OrderStatus, CreatedBy)
                        OUTPUT INSERTED.OrderID
                        VALUES (@OrderNumber, @CustomerId, @ShippingAddressId, @BillingAddressId, @WarehouseId, @Status, @CreatedBy);",
                        connection, transaction))
                    {
                        insertOrder.Parameters.Add("@OrderNumber", SqlDbType.VarChar, 30).Value = orderNumber;
                        insertOrder.Parameters.Add("@CustomerId", SqlDbType.Int).Value = customerId;
                        insertOrder.Parameters.Add("@ShippingAddressId", SqlDbType.Int).Value = shippingAddressId;
                        insertOrder.Parameters.Add("@BillingAddressId", SqlDbType.Int).Value = billingAddressId;
                        insertOrder.Parameters.Add("@WarehouseId", SqlDbType.Int).Value = warehouseId;
                        insertOrder.Parameters.Add("@Status", SqlDbType.VarChar, 20).Value = OrderStatuses.Pending;
                        insertOrder.Parameters.Add("@CreatedBy", SqlDbType.VarChar, 50).Value = (object)createdBy ?? DBNull.Value;
                        orderId = (int)insertOrder.ExecuteScalar();
                    }

                    decimal subTotal = 0m;
                    var lineNumber = 1;
                    foreach (var line in lines)
                    {
                        if (line.Quantity <= 0)
                        {
                            continue;
                        }

                        var unitPrice = GetCurrentUnitPrice(connection, transaction, line.ProductId);

                        using (var insertLine = new SqlCommand(@"
                            INSERT INTO dbo.OrderLines
                                (OrderID, LineNumber, ProductID, WarehouseID, Quantity, UnitPrice, DiscountPercent)
                            VALUES (@OrderId, @LineNumber, @ProductId, @WarehouseId, @Quantity, @UnitPrice, 0);",
                            connection, transaction))
                        {
                            insertLine.Parameters.Add("@OrderId", SqlDbType.Int).Value = orderId;
                            insertLine.Parameters.Add("@LineNumber", SqlDbType.Int).Value = lineNumber;
                            insertLine.Parameters.Add("@ProductId", SqlDbType.Int).Value = line.ProductId;
                            insertLine.Parameters.Add("@WarehouseId", SqlDbType.Int).Value = warehouseId;
                            insertLine.Parameters.Add("@Quantity", SqlDbType.Int).Value = line.Quantity;
                            insertLine.Parameters.Add("@UnitPrice", SqlDbType.Decimal).Value = unitPrice;
                            insertLine.ExecuteNonQuery();
                        }

                        subTotal += unitPrice * line.Quantity;
                        lineNumber++;
                    }

                    if (lineNumber == 1)
                    {
                        throw new InvalidOperationException("An order must contain at least one product line with a quantity greater than zero.");
                    }

                    var taxAmount = Math.Round(subTotal * TaxRate, 2, MidpointRounding.AwayFromZero);
                    var shippingAmount = FlatShippingAmount;
                    var totalAmount = subTotal + taxAmount + shippingAmount;

                    using (var updateTotals = new SqlCommand(@"
                        UPDATE dbo.Orders
                        SET SubTotal = @SubTotal, TaxAmount = @TaxAmount, ShippingAmount = @ShippingAmount,
                            TotalAmount = @TotalAmount, ModifiedDate = SYSUTCDATETIME()
                        WHERE OrderID = @OrderId;",
                        connection, transaction))
                    {
                        updateTotals.Parameters.Add("@SubTotal", SqlDbType.Decimal).Value = subTotal;
                        updateTotals.Parameters.Add("@TaxAmount", SqlDbType.Decimal).Value = taxAmount;
                        updateTotals.Parameters.Add("@ShippingAmount", SqlDbType.Decimal).Value = shippingAmount;
                        updateTotals.Parameters.Add("@TotalAmount", SqlDbType.Decimal).Value = totalAmount;
                        updateTotals.Parameters.Add("@OrderId", SqlDbType.Int).Value = orderId;
                        updateTotals.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return orderId;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public OrderDetailsModel GetById(int orderId)
        {
            const string headerSql = @"
                SELECT o.OrderID, o.OrderNumber, o.CustomerID, c.CompanyName, o.OrderDate, o.OrderStatus,
                       o.SubTotal, o.TaxAmount, o.ShippingAmount, o.TotalAmount
                FROM dbo.Orders o
                JOIN dbo.Customers c ON c.CustomerID = o.CustomerID
                WHERE o.OrderID = @OrderId;";

            const string linesSql = @"
                SELECT ol.ProductID, p.SKU, p.ProductName, ol.Quantity, ol.UnitPrice, ol.LineTotal
                FROM dbo.OrderLines ol
                JOIN dbo.ProductCatalog p ON p.ProductID = ol.ProductID
                WHERE ol.OrderID = @OrderId
                ORDER BY ol.LineNumber;";

            using (var connection = DbHelper.GetOpenConnection())
            {
                OrderDetailsModel order = null;
                using (var command = new SqlCommand(headerSql, connection))
                {
                    command.Parameters.Add("@OrderId", SqlDbType.Int).Value = orderId;
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            order = new OrderDetailsModel
                            {
                                OrderId = reader.GetInt32(reader.GetOrdinal("OrderID")),
                                OrderNumber = reader.GetString(reader.GetOrdinal("OrderNumber")),
                                CustomerId = reader.GetInt32(reader.GetOrdinal("CustomerID")),
                                CustomerName = reader.GetString(reader.GetOrdinal("CompanyName")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("OrderDate")),
                                OrderStatus = reader.GetString(reader.GetOrdinal("OrderStatus")),
                                SubTotal = reader.GetDecimal(reader.GetOrdinal("SubTotal")),
                                TaxAmount = reader.GetDecimal(reader.GetOrdinal("TaxAmount")),
                                ShippingAmount = reader.GetDecimal(reader.GetOrdinal("ShippingAmount")),
                                OrderTotal = reader.GetDecimal(reader.GetOrdinal("TotalAmount"))
                            };
                        }
                    }
                }

                if (order == null)
                {
                    return null;
                }

                using (var command = new SqlCommand(linesSql, connection))
                {
                    command.Parameters.Add("@OrderId", SqlDbType.Int).Value = orderId;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            order.Lines.Add(new OrderLineDetailModel
                            {
                                ProductId = reader.GetInt32(reader.GetOrdinal("ProductID")),
                                Sku = reader.GetString(reader.GetOrdinal("SKU")),
                                ProductName = reader.GetString(reader.GetOrdinal("ProductName")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                UnitPrice = reader.GetDecimal(reader.GetOrdinal("UnitPrice")),
                                LineTotal = reader.GetDecimal(reader.GetOrdinal("LineTotal"))
                            });
                        }
                    }
                }

                return order;
            }
        }

        public bool UpdateStatus(int orderId, string newStatus)
        {
            const string sql = @"
                UPDATE dbo.Orders
                SET OrderStatus = @Status, ModifiedDate = SYSUTCDATETIME()
                WHERE OrderID = @OrderId;";

            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand(sql, connection))
            {
                command.Parameters.Add("@Status", SqlDbType.VarChar, 20).Value = newStatus;
                command.Parameters.Add("@OrderId", SqlDbType.Int).Value = orderId;
                return command.ExecuteNonQuery() > 0;
            }
        }

        private static int GetAddressId(SqlConnection connection, SqlTransaction transaction, int customerId, string addressType)
        {
            const string sql = @"
                SELECT TOP (1) AddressID FROM dbo.CustomerAddresses
                WHERE CustomerID = @CustomerId AND AddressType = @AddressType
                ORDER BY IsPrimary DESC, AddressID;";

            using (var command = new SqlCommand(sql, connection, transaction))
            {
                command.Parameters.Add("@CustomerId", SqlDbType.Int).Value = customerId;
                command.Parameters.Add("@AddressType", SqlDbType.VarChar, 20).Value = addressType;
                var result = command.ExecuteScalar();
                if (result == null)
                {
                    throw new InvalidOperationException(
                        string.Format("Customer {0} has no {1} address on file; cannot create the order.", customerId, addressType));
                }
                return (int)result;
            }
        }

        private static int GetDefaultWarehouseId(SqlConnection connection, SqlTransaction transaction)
        {
            const string sql = "SELECT TOP (1) WarehouseID FROM dbo.Warehouses WHERE IsActive = 1 ORDER BY WarehouseID;";
            using (var command = new SqlCommand(sql, connection, transaction))
            {
                var result = command.ExecuteScalar();
                if (result == null)
                {
                    throw new InvalidOperationException("No active warehouse is configured; cannot create the order.");
                }
                return (int)result;
            }
        }

        private static decimal GetCurrentUnitPrice(SqlConnection connection, SqlTransaction transaction, int productId)
        {
            const string sql = "SELECT UnitPrice FROM dbo.ProductCatalog WHERE ProductID = @ProductId AND IsActive = 1;";
            using (var command = new SqlCommand(sql, connection, transaction))
            {
                command.Parameters.Add("@ProductId", SqlDbType.Int).Value = productId;
                var result = command.ExecuteScalar();
                if (result == null)
                {
                    throw new InvalidOperationException(string.Format("Product {0} was not found or is not active.", productId));
                }
                return (decimal)result;
            }
        }
    }
}
