using System.Collections.Generic;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Repositories
{
    public interface IOrderRepository
    {
        List<LookupItem> GetCustomersForDropdown();
        List<LookupItem> GetProductsForDropdown();

        // Creates the order header + lines in a single transaction and returns the new OrderID.
        int CreateOrder(int customerId, List<OrderLineInputModel> lines, string createdBy, out string orderNumber);

        OrderDetailsModel GetById(int orderId);

        // Returns true if a matching order was found and updated.
        bool UpdateStatus(int orderId, string newStatus);
    }
}
