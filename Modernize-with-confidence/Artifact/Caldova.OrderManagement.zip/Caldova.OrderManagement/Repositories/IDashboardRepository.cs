namespace Caldova.OrderManagement.Repositories
{
    public interface IDashboardRepository
    {
        int GetTotalProducts();
        int GetAvailableProductsCount();
        int GetOpenOrdersCount();
        int GetPendingShipmentsCount();
    }
}
