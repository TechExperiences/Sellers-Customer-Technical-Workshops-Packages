using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Caldova.OrderManagement.Data;
using Caldova.OrderManagement.Models;

namespace Caldova.OrderManagement.Repositories
{
    public class ProductRepository : IProductRepository
    {
        // One row per Product+Warehouse (matches the Inventory grain), so availability
        // and warehouse are always shown together. Every filter is parameterized to avoid
        // SQL injection; LIKE wildcards are appended in the parameter value, never concatenated into the SQL text.
        public List<ProductAvailabilityModel> Search(ProductSearchCriteria criteria)
        {
            var sql = new StringBuilder(@"
                SELECT
                    p.ProductID, p.SKU, p.ProductName, c.CategoryName,
                    pd.ShortDescription, p.UnitPrice,
                    i.QuantityAvailable, i.ReorderLevel, w.WarehouseName
                FROM dbo.ProductCatalog p
                JOIN dbo.ProductCategories c ON c.CategoryID = p.CategoryID
                LEFT JOIN dbo.ProductDescriptions pd ON pd.ProductID = p.ProductID AND pd.LanguageCode = 'en-US'
                JOIN dbo.Inventory i ON i.ProductID = p.ProductID
                JOIN dbo.Warehouses w ON w.WarehouseID = i.WarehouseID
                WHERE p.IsActive = 1");

            using (var connection = DbHelper.GetOpenConnection())
            using (var command = new SqlCommand())
            {
                command.Connection = connection;

                if (criteria.ProductId.HasValue)
                {
                    sql.Append(" AND p.ProductID = @ProductId");
                    command.Parameters.Add("@ProductId", SqlDbType.Int).Value = criteria.ProductId.Value;
                }
                if (!string.IsNullOrWhiteSpace(criteria.Sku))
                {
                    sql.Append(" AND p.SKU LIKE @Sku");
                    command.Parameters.Add("@Sku", SqlDbType.VarChar, 30).Value = "%" + criteria.Sku.Trim() + "%";
                }
                if (!string.IsNullOrWhiteSpace(criteria.ProductName))
                {
                    sql.Append(" AND p.ProductName LIKE @ProductName");
                    command.Parameters.Add("@ProductName", SqlDbType.VarChar, 200).Value = "%" + criteria.ProductName.Trim() + "%";
                }
                if (!string.IsNullOrWhiteSpace(criteria.Category))
                {
                    sql.Append(" AND c.CategoryName LIKE @Category");
                    command.Parameters.Add("@Category", SqlDbType.VarChar, 100).Value = "%" + criteria.Category.Trim() + "%";
                }
                if (!string.IsNullOrWhiteSpace(criteria.DescriptionKeyword))
                {
                    // Scenario 6: traditional SQL/LIKE search across product descriptions.
                    sql.Append(" AND (pd.ShortDescription LIKE @Keyword OR pd.LongDescription LIKE @Keyword)");
                    command.Parameters.Add("@Keyword", SqlDbType.VarChar, 4000).Value = "%" + criteria.DescriptionKeyword.Trim() + "%";
                }

                sql.Append(" ORDER BY p.ProductName, w.WarehouseName;");
                command.CommandText = sql.ToString();

                var results = new List<ProductAvailabilityModel>();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        results.Add(new ProductAvailabilityModel
                        {
                            ProductId = reader.GetInt32(reader.GetOrdinal("ProductID")),
                            Sku = reader.GetString(reader.GetOrdinal("SKU")),
                            ProductName = reader.GetString(reader.GetOrdinal("ProductName")),
                            Category = reader.GetString(reader.GetOrdinal("CategoryName")),
                            Description = reader.IsDBNull(reader.GetOrdinal("ShortDescription")) ? string.Empty : reader.GetString(reader.GetOrdinal("ShortDescription")),
                            UnitPrice = reader.GetDecimal(reader.GetOrdinal("UnitPrice")),
                            AvailableQuantity = reader.GetInt32(reader.GetOrdinal("QuantityAvailable")),
                            ReorderLevel = reader.GetInt32(reader.GetOrdinal("ReorderLevel")),
                            Warehouse = reader.GetString(reader.GetOrdinal("WarehouseName"))
                        });
                    }
                }
                return results;
            }
        }
    }
}
