namespace Caldova.OrderManagement.Models
{
    // Search inputs for the Customer Lookup module.
    public class CustomerSearchCriteria
    {
        public int? CustomerId { get; set; }
        public string CustomerName { get; set; }

        public bool IsEmpty
        {
            get { return !CustomerId.HasValue && string.IsNullOrWhiteSpace(CustomerName); }
        }
    }
}
