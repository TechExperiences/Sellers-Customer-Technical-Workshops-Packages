using System.Collections.Generic;

namespace Caldova.OrderManagement.Models
{
    public class CustomerSearchViewModel
    {
        public CustomerSearchCriteria Criteria { get; set; }
        public List<CustomerModel> Results { get; set; }
        public bool HasSearched { get; set; }

        public CustomerSearchViewModel()
        {
            Criteria = new CustomerSearchCriteria();
            Results = new List<CustomerModel>();
        }
    }
}
