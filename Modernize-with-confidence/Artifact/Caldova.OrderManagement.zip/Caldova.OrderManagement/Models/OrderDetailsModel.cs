using System;
using System.Collections.Generic;

namespace Caldova.OrderManagement.Models
{
    public class OrderDetailsModel
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public DateTime OrderDate { get; set; }
        public string OrderStatus { get; set; }
        public decimal SubTotal { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal ShippingAmount { get; set; }
        public decimal OrderTotal { get; set; }
        public List<OrderLineDetailModel> Lines { get; set; }

        public OrderDetailsModel()
        {
            Lines = new List<OrderLineDetailModel>();
        }
    }
}
