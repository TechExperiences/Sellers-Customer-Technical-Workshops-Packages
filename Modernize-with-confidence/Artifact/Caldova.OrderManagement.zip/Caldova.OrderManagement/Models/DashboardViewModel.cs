namespace Caldova.OrderManagement.Models
{
    public class DashboardViewModel
    {
        public int TotalProducts { get; set; }
        public int AvailableProducts { get; set; }
        public int OpenOrders { get; set; }
        public int PendingShipments { get; set; }
    }
}
