using System.Collections.Generic;

namespace Caldova.OrderManagement.Models
{
    public class ProductSearchViewModel
    {
        public ProductSearchCriteria Criteria { get; set; }
        public List<ProductAvailabilityModel> Results { get; set; }
        public bool HasSearched { get; set; }

        public ProductSearchViewModel()
        {
            Criteria = new ProductSearchCriteria();
            Results = new List<ProductAvailabilityModel>();
        }
    }
}
