namespace Caldova.OrderManagement.Models
{
    public class OrderLookupViewModel
    {
        public int? OrderId { get; set; }
        public bool HasSearched { get; set; }
        public string ErrorMessage { get; set; }
        public OrderDetailsModel Order { get; set; }
    }
}
