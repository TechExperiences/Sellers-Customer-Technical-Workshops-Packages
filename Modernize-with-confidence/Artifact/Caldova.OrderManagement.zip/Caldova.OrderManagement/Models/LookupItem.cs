namespace Caldova.OrderManagement.Models
{
    // Simple id/display-text pair used to populate dropdowns without leaking MVC types into repositories.
    public class LookupItem
    {
        public int Id { get; set; }
        public string DisplayText { get; set; }
    }
}
