using System.Collections.Generic;
using System.Linq;

namespace Caldova.OrderManagement.Models
{
    // Central list of order statuses the application supports (Order Status module).
    public static class OrderStatuses
    {
        public const string Pending = "Pending";
        public const string Confirmed = "Confirmed";
        public const string Processing = "Processing";
        public const string Shipped = "Shipped";
        public const string Delivered = "Delivered";
        public const string Cancelled = "Cancelled";

        public static readonly IReadOnlyList<string> All = new List<string>
        {
            Pending, Confirmed, Processing, Shipped, Delivered, Cancelled
        };

        public static bool IsValid(string status)
        {
            return !string.IsNullOrEmpty(status) && All.Contains(status);
        }
    }
}
