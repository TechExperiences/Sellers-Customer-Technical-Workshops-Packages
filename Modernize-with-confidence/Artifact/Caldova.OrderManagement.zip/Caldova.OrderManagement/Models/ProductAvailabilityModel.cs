namespace Caldova.OrderManagement.Models
{
    public class ProductAvailabilityModel
    {
        public int ProductId { get; set; }
        public string Sku { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public decimal UnitPrice { get; set; }
        public int AvailableQuantity { get; set; }
        public int ReorderLevel { get; set; }
        public string Warehouse { get; set; }
    }
}
