namespace Caldova.OrderManagement.Models
{
    // Search inputs for the Product Availability module (Scenario 1 and 6).
    public class ProductSearchCriteria
    {
        public int? ProductId { get; set; }
        public string Sku { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }

        // Free-text keyword matched against product descriptions with LIKE (Scenario 6).
        public string DescriptionKeyword { get; set; }

        public bool IsEmpty
        {
            get
            {
                return !ProductId.HasValue
                    && string.IsNullOrWhiteSpace(Sku)
                    && string.IsNullOrWhiteSpace(ProductName)
                    && string.IsNullOrWhiteSpace(Category)
                    && string.IsNullOrWhiteSpace(DescriptionKeyword);
            }
        }
    }
}
