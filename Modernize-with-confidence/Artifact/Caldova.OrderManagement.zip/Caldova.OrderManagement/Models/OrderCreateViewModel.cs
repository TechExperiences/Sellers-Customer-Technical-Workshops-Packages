using System.Collections.Generic;
using System.Web.Mvc;

namespace Caldova.OrderManagement.Models
{
    public class OrderCreateViewModel
    {
        public int CustomerId { get; set; }
        public List<OrderLineInputModel> Lines { get; set; }

        public List<SelectListItem> CustomerOptions { get; set; }
        public List<SelectListItem> ProductOptions { get; set; }

        public OrderCreateViewModel()
        {
            Lines = new List<OrderLineInputModel> { new OrderLineInputModel(), new OrderLineInputModel(), new OrderLineInputModel() };
            CustomerOptions = new List<SelectListItem>();
            ProductOptions = new List<SelectListItem>();
        }
    }

    public class OrderLineInputModel
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
